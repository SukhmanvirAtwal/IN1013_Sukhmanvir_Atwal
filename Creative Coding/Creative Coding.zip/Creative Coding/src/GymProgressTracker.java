//@author: Sukhmanvir Atwal
//references: w3schools for file writing and how to do it
//reference link: https://www.w3schools.com/java/java_files_create.asp

import java.io.*;
import java.util.Scanner;

public class GymProgressTracker
{

    private static final String DATA_FILE = "GymProgress.txt";

    //Main method is used to display the options to the user, from which they can pick from.
    //E.g., Logging a workout, viewing progress, or exiting. 
    //This is where a data file will be initiated (if it already doesn't exist).
    //This means that a new text file will be created in the appropriate area on your computer. 
    public static void main(String[] args) 
    {
        initializeDataFile();
        Scanner szInput = new Scanner(System.in);

        while (true) 
        {
            System.out.println("Gym Progress Tracker:");
            System.out.println("1. Log a workout");
            System.out.println("2. View progress");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            String szChoice = szInput.nextLine();

            switch (szChoice) 
            {
                case "1":
                    logWorkout(szInput);
                    break;
                
                case "2":
                    viewProgress();
                    break;
                
                case "3":
                    System.out.println("Exiting the program. Keep pushing yourself!");
                    szInput.close();
                    return;
               
                default:
                    System.out.println("Invalid input. Please try again.");
            }
        }
    }

    //Method used to initialise a data file if it doesn't already exist. 
    //Reference: w3schools
    private static void initializeDataFile() 
    {
        File newFile = new File(DATA_FILE);
        if (!newFile.exists()) 
        {
            try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE)))
            {
                writer.println("Date | Exercise | Reps | Weight (kg)");
            } 
            
            catch (IOException e) 
            {
                System.out.println("Error initializing data file: " + e.getMessage());
            }
        }
    }

    //Method which is used to add a new workout to the .txt file
    //This method will be used if the user were to pick the first option. 
    private static void logWorkout(Scanner szInput)
    {
        System.out.print("Enter the date (YYYY-MM-DD): ");
        String szDate = szInput.nextLine();
        System.out.print("Enter the exercise name: ");
        String szExercise = szInput.nextLine();
        System.out.print("Enter the number of reps: ");
        String szReps = szInput.nextLine();
        System.out.print("Enter the weight used (kg): ");
        String szWeight = szInput.nextLine();

        //reference: w3schools
        try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE, true))) 
        {
            writer.println(szDate + " | " + szExercise + " | " + szReps + " | " + szWeight);
            System.out.println("Workout logged successfully!");
        } 
        
        catch (IOException e) 
        {
            System.out.println("Error logging workout: " + e.getMessage());
        }
    }

    //Method which is used to read the text file, which can be used to view progress.
    //This method will be used if the user decides to view their current progress. 
    private static void viewProgress() 
    {
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE)))
        {
            String szLine;
            while ((szLine = reader.readLine()) != null)
            {
                System.out.println(szLine);
            }
        }
        
        catch (IOException e)
        {
            System.out.println("Error reading progress: " + e.getMessage());
        }
    }
}
